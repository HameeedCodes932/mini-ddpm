"""Check diffusion equations and computational contracts, independently of quality."""
import json
import math
import unittest
from pathlib import Path
import torch
from torch import nn
from mini_ddpm import Diffusion,SmallUNet,feature_distance

class Tests(unittest.TestCase):
    def setUp(self):torch.manual_seed(123);torch.set_num_threads(2)
    def test_closed_form_noising(self):
        d=Diffusion();x=torch.randn(3,1,28,28);z=torch.randn_like(x);t=torch.tensor([0,499,999])
        a=d.alpha_bars[t].float().view(-1,1,1,1)
        torch.testing.assert_close(d.q_sample(x,t,z),a.sqrt()*x+(1-a).sqrt()*z)
        self.assertLess(float(d.alpha_bars[-1]),.0001)
    def test_posterior_matches_original_adjacent_formula(self):
        d=Diffusion()
        for t in (1,10,500,999):
            c0,ct,var=d.coefficients(t,t-1);a=d.alpha_bars[t];s=d.alpha_bars[t-1];beta=d.betas[t]
            self.assertAlmostEqual(float(c0),float(s.sqrt()*beta/(1-a)),places=6)
            self.assertAlmostEqual(float(ct),float(d.alphas[t].sqrt()*(1-s)/(1-a)),places=6)
            self.assertAlmostEqual(float(var),float(beta*(1-s)/(1-a)),places=6)
    def test_final_transition_has_no_noise(self):
        for t in (0,49,999):
            c0,ct,var=Diffusion().coefficients(t,-1)
            self.assertAlmostEqual(float(c0),1.);self.assertEqual(float(ct),0.);self.assertEqual(float(var),0.)
    def test_respacing_preserves_forward_marginals(self):
        d=Diffusion()
        for steps in (1000,200,50):
            indices=d.indices(steps);self.assertEqual(len(indices),steps)
            product=torch.tensor(1.,dtype=torch.float64)
            previous=torch.tensor(1.,dtype=torch.float64)
            for t in indices[::-1]:
                product*=d.alpha_bars[t]/previous
                torch.testing.assert_close(product,d.alpha_bars[t],rtol=1e-12,atol=1e-12)
                previous=d.alpha_bars[t]
    def test_unet_shape_parameters_and_cpu_gradient(self):
        model=SmallUNet();self.assertLessEqual(sum(p.numel() for p in model.parameters()),5_000_000)
        x=torch.randn(2,1,28,28);y=model(x,torch.tensor([0,999]));self.assertEqual(x.shape,y.shape)
        y.square().mean().backward()
        self.assertTrue(all(p.grad is not None and torch.isfinite(p.grad).all() for p in model.parameters()))
    def test_sampler_counts_and_determinism(self):
        class Zero(nn.Module):
            def __init__(self):super().__init__();self.anchor=nn.Parameter(torch.zeros(()));self.calls=0
            def forward(self,x,t):self.calls+=1;return torch.zeros_like(x)+self.anchor
        d=Diffusion()
        for steps in (1000,200,50):
            model=Zero();a=d.sample(model,2,steps,88);self.assertEqual(model.calls,steps)
            b=d.sample(model,2,steps,88);torch.testing.assert_close(a,b,rtol=0,atol=0)
            self.assertTrue(torch.isfinite(a).all());self.assertTrue((a.abs()<=1).all())
        model=Zero();a=d.sample(model,2,50,11,'ddim');b=d.sample(model,2,50,11,'ddim')
        torch.testing.assert_close(a,b,rtol=0,atol=0)
    def test_feature_distance_identity_and_symmetry(self):
        a=(torch.tensor([1.,2.],dtype=torch.float64),torch.diag(torch.tensor([2.,3.],dtype=torch.float64)))
        b=(torch.tensor([2.,4.],dtype=torch.float64),torch.diag(torch.tensor([4.,1.],dtype=torch.float64)))
        self.assertAlmostEqual(feature_distance(a,a),0.,places=7)
        expected=5+(math.sqrt(2)-2)**2+(math.sqrt(3)-1)**2
        self.assertAlmostEqual(feature_distance(a,b),expected,places=7)
        self.assertAlmostEqual(feature_distance(a,b),feature_distance(b,a),places=7)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Tests)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    Path('tests_result.json').write_text(json.dumps({'tests':result.testsRun,'failures':len(result.failures),'errors':len(result.errors),'passed':result.wasSuccessful()},indent=2))
    raise SystemExit(0 if result.wasSuccessful() else 1)
