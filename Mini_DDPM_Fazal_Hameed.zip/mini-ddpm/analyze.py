"""Create figures from saved measured histories; never generate assumed scores."""
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parent
def main():
    result=json.loads((ROOT/'runs/main/training_result.json').read_text())
    comparison=json.loads((ROOT/'results/comparison.json').read_text())
    assert result['training_completed'] and len(result['history'])==12
    assert {(r['method'],r['steps']) for r in comparison['rows']}=={('ddpm',1000),('ddpm',200),('ddpm',50),('ddim',50)}
    history=result['history']
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False})
    fig,ax=plt.subplots(figsize=(6,3.2))
    ax.plot([r['epoch'] for r in history],[r['training_mse'] for r in history],marker='o',label='Training (online weights)',color='#1d5a78')
    ax.plot([r['epoch'] for r in history],[r['validation_mse_ema'] for r in history],marker='s',label='Validation (EMA weights)',color='#cf6b2e')
    ax.set(xlabel='Epoch',ylabel='Noise-prediction MSE',title='Recorded loss curves')
    ax.legend(fontsize=8);ax.grid(alpha=.2);fig.tight_layout()
    fig.savefig(ROOT/'results/loss_curves.png',dpi=200);plt.close(fig)
    rows=comparison['rows'];baseline=next(r for r in rows if r['method']=='ddpm' and r['steps']==1000)
    for row in rows:row['speedup_vs_ddpm1000']=baseline['median_64_seconds']/row['median_64_seconds']
    summary={'parameters':result['config']['parameters'],'epochs':12,'updates':result['updates'],
        'training_seconds':result['training_seconds'],'environment':result['config']['environment'],
        'final_training_mse':history[-1]['training_mse'],'final_validation_mse_ema':history[-1]['validation_mse_ema'],
        'classifier_test_accuracy':comparison['classifier_result']['test_accuracy'],
        'real_reference_calibration_distance':comparison['real_reference_calibration_distance'],'rows':rows}
    (ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2),encoding='utf-8')
    print(json.dumps(summary,indent=2))

if __name__=='__main__':main()
