"""Repeat comparisons using the already trained, fixed evaluator checkpoint."""
from types import SimpleNamespace
import argparse
import json
import torch
import mini_ddpm as experiment

def restore_classifier(device):
    path=experiment.ROOT/'runs/classifier.pt'
    state=torch.load(path,map_location='cpu',weights_only=False)
    assert state['result']['epochs']==3 and state['result']['seed']==2718
    assert state['result']==json.loads((experiment.ROOT/'runs/classifier_result.json').read_text())
    model=experiment.DigitClassifier().to(device);model.load_state_dict(state['model']);model.eval()
    _,_,test_raw,_=experiment.load_mnist(experiment.ROOT/'data')
    test_x=test_raw.to(device,dtype=torch.float32)/127.5-1
    print('RESTORED_FIXED_CLASSIFIER',state['result']['test_accuracy'],flush=True)
    return model,test_x

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device',default='cpu',choices=['cpu','cuda'])
    parser.add_argument('--threads',type=int,default=4)
    args=parser.parse_args()
    experiment.train_classifier=restore_classifier
    experiment.evaluate(args)
