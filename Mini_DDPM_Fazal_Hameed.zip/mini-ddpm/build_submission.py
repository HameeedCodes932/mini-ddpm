"""Create a source-and-weights submission with an auditable file manifest."""
import ast
import hashlib
import json
from pathlib import Path
import zipfile

ROOT=Path(__file__).resolve().parent
OUT=ROOT.parent/'Mini_DDPM_Fazal_Hameed.zip'
def include(path):
    relative=path.relative_to(ROOT)
    return (path.is_file() and not any(p in ('tmp','data','artifacts','__pycache__','.venv') for p in relative.parts)
        and path.name not in ('resume.pt','project_manifest.json','drive_delivery_verification.json')
        and not path.name.endswith(('.tmp','.copying')))
files=sorted((p for p in ROOT.rglob('*') if include(p)),key=lambda p:p.relative_to(ROOT).as_posix())
for p in files:
    if p.suffix=='.py':ast.parse(p.read_text(encoding='utf-8'),filename=str(p.relative_to(ROOT)))
    if p.suffix=='.ipynb':
        notebook=json.loads(p.read_text(encoding='utf-8'))
        for cell in notebook['cells']:
            if cell['cell_type']=='code':ast.parse(''.join(cell['source']))
manifest={'project':'mini-ddpm','author':'Fazal Hameed','date':'2026-10-18',
    'scope':'From-scratch MNIST DDPM; T4 measurements; CPU-compatible source; single training seed.',
    'files':[{'path':str(p.relative_to(ROOT)).replace('\\','/'),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]}
manifest_path=ROOT/'project_manifest.json';manifest_path.write_bytes(json.dumps(manifest,indent=2).encode('utf-8'))
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
    for p in files+[manifest_path]:
        info=zipfile.ZipInfo('mini-ddpm/'+p.relative_to(ROOT).as_posix(),date_time=(2026,10,18,0,0,0))
        info.create_system=3;info.external_attr=0o644<<16;info.compress_type=zipfile.ZIP_DEFLATED
        archive.writestr(info,p.read_bytes(),compresslevel=9)
with zipfile.ZipFile(OUT) as archive:
    assert archive.testzip() is None
    for record in manifest['files']:
        data=archive.read('mini-ddpm/'+record['path'])
        assert len(data)==record['bytes'] and hashlib.sha256(data).hexdigest()==record['sha256']
    required=['mini_ddpm.py','sample.py','test_ddpm.py','mini_ddpm_colab.ipynb','runs/main/model_ema.pt',
        'runs/classifier.pt','results/comparison.json','results/loss_curves.png',
        'results/grid_ddpm_1000.png','results/grid_ddpm_200.png','results/grid_ddpm_50.png',
        'results/grid_ddim_50.png','output/pdf/Mini_DDPM_Report_Fazal_Hameed.pdf']
    assert all('mini-ddpm/'+p in archive.namelist() for p in required)
sha=hashlib.sha256(OUT.read_bytes()).hexdigest()
OUT.with_suffix('.zip.sha256').write_text(sha+'  '+OUT.name+'\n',encoding='ascii')
print(json.dumps({'archive':str(OUT),'bytes':OUT.stat().st_size,'files':len(files)+1,'sha256':sha}))
