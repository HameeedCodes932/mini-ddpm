# mini-ddpm: MNIST diffusion from scratch

Author: Fazal Hameed.

This project implements the forward diffusion schedule, direct noising,
time-conditioned small U-Net, noise-prediction MSE, ancestral DDPM sampling,
correct posterior respacing, and the optional deterministic DDIM sampler using
basic PyTorch. It uses no pretrained generator or diffusion framework.

The program defaults to CPU. The recorded experiments use a free Colab T4 for
speed; GPU times must not be presented as laptop CPU times. The U-Net has 550,465
parameters, below the five-million limit.

## Install and verify

Use Python 3.10 or newer. From this folder:

```text
python -m pip install -r requirements.txt
python test_ddpm.py
```

The tests check the noising equation, adjacent and respaced posterior formulas,
the clean final transition, exact model-evaluation counts, seeded sampling,
finite CPU gradients and classifier feature-distance calculations. They do not
establish image quality.

## Generate samples with the included weights

No dataset download is needed for these commands:

```text
python sample.py --device cpu --method ddpm --steps 1000 --output ddpm_1000.png
python sample.py --device cpu --method ddpm --steps 200 --output ddpm_200.png
python sample.py --device cpu --method ddpm --steps 50 --output ddpm_50.png
python sample.py --device cpu --method ddim --steps 50 --output ddim_50.png
```

Each command writes an 8x8 grid. CUDA is optional: replace `--device cpu` with
`--device cuda` when supported. CPU speed depends on hardware and thread count.
The default sampling seed is 2026; no samples are filtered or selected by quality.

## Reproduce training and comparisons

Use a fresh project folder for a new run. MNIST is downloaded from the mirror
used by Torchvision, and all four original gzip MD5 checksums are verified.

```text
python mini_ddpm.py train --device cpu --threads 4
python mini_ddpm.py evaluate --device cpu --threads 4
python analyze.py
```

On Colab, use `--device cuda --threads 2` for training and evaluation. The clean
notebook contains the exact source and commands. Defaults match the recorded
12-epoch, seed-42, batch-256 experiment. An interrupted training command resumes
from the last completed epoch only when its configuration, environment and
source hashes match. An unfinished epoch is repeated. Resumed wall times are
recorded per invocation, while epoch training times are accumulated. Bitwise
equivalence across CPU/GPU or CUDA library versions is not guaranteed.

`evaluate` fits the fixed three-epoch digit classifier from scratch, evaluates
its test accuracy, runs three rotated-order timing repetitions, generates 512
unfiltered images per sampling setting and writes grids/metrics. Run this in the
matching source version. The optional `MINIDDPM_BACKUP` environment variable
enables verified project-file backups to a mounted Drive directory.

## Read the evidence

- `PROTOCOL.md`: plan written before training.
- `runs/main/config.json`, `history.json`, `training_result.json`: setup and losses.
- `runs/main/model_ema.pt`: final EMA generator weights and configuration.
- `runs/classifier.pt`, `classifier_result.json`: evaluator weights and accuracy.
- `results/grid_ddpm_1000.png`, `grid_ddpm_200.png`, `grid_ddpm_50.png`: required grids.
- `results/grid_ddim_50.png`: optional bonus grid.
- `results/samples_*.npz`: all 512 generated 8-bit images per setting.
- `results/comparison.json`, `comparison.csv`, `summary.json`: measured comparisons.
- `results/loss_curves.png`, `forward_noising.png`: method/training figures.
- `output/pdf/Mini_DDPM_Report_Fazal_Hameed.pdf`: three-page experimental report.

The respaced samplers cover the original 1,000-step noise range. The experiment
does not train separate 200- or 50-timestep generators. The 64-dimensional MNIST
classifier feature distance is a diagnostic, not standard Inception FID.
Classifier confidence on unlabeled generated images is not their accuracy.
One generator training seed and 512 samples per setting limit general conclusions.

## References and data

- Ho, Jain and Abbeel, Denoising Diffusion Probabilistic Models (2020):
  https://arxiv.org/abs/2006.11239 .
- Song, Meng and Ermon, Denoising Diffusion Implicit Models (2020):
  https://arxiv.org/abs/2010.02502 .
- Respaced posterior reference:
  https://github.com/openai/improved-diffusion/blob/main/improved_diffusion/respace.py .
- MNIST: LeCun, Cortes and Burges. The original IDX image/label files are fetched
  from https://ossci-datasets.s3.amazonaws.com/mnist/ using checksums documented
  in https://github.com/pytorch/vision/blob/main/torchvision/datasets/mnist.py .
  Raw dataset files are not redistributed in the submission ZIP.
