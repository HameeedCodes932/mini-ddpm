"""Small DDPM for MNIST. Equations follow Ho et al., arXiv:2006.11239.

All diffusion equations and the U-Net are implemented here using basic PyTorch.
No diffusion library, pretrained generator or pretrained evaluator is used.
"""
import argparse
import copy
import csv
import gzip
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import struct
import time
import urllib.request

import numpy as np
from PIL import Image
import torch
from torch import nn
import torch.nn.functional as F

ROOT=Path(__file__).resolve().parent
RESOURCES={
 'train-images-idx3-ubyte.gz':'f68b3c2dcbeaaa9fbdd348bbdeb94873',
 'train-labels-idx1-ubyte.gz':'d53e105ee54ea40749a09fcbcd1e9432',
 't10k-images-idx3-ubyte.gz':'9fb629c4189551a2d022fa330f9573f3',
 't10k-labels-idx1-ubyte.gz':'ec29112dd5afa0611ce80d1b7f02629c',
}

def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def write_json(path,obj):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(obj,indent=2),encoding='utf-8')

def atomic_save(obj,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.tmp')
    torch.save(obj,temp);os.replace(temp,path)

def backup(path):
    """Optional verified backup, limited to the explicitly configured project."""
    folder=os.environ.get('MINIDDPM_BACKUP')
    if not folder:return None
    path=Path(path);relative=path.resolve().relative_to(ROOT.resolve())
    target=Path(folder)/relative;target.parent.mkdir(parents=True,exist_ok=True)
    expected=sha256(path)
    temp=target.with_name(target.name+'.copying')
    with path.open('rb') as source,temp.open('wb') as destination:
        shutil.copyfileobj(source,destination)
        destination.flush();os.fsync(destination.fileno())
    assert sha256(temp)==expected,'Backup checksum mismatch'
    os.replace(temp,target)
    return {'path':str(relative),'bytes':path.stat().st_size,'sha256':expected}

def load_mnist(data_root):
    data_root=Path(data_root);data_root.mkdir(parents=True,exist_ok=True)
    arrays={}
    for name,md5 in RESOURCES.items():
        target=data_root/name
        if not target.exists():
            urllib.request.urlretrieve('https://ossci-datasets.s3.amazonaws.com/mnist/'+name,target)
        assert hashlib.md5(target.read_bytes()).hexdigest()==md5,name
        raw=gzip.decompress(target.read_bytes())
        magic,count=struct.unpack('>II',raw[:8])
        if magic==2051:
            height,width=struct.unpack('>II',raw[8:16]);assert (height,width)==(28,28)
            array=np.frombuffer(raw,dtype=np.uint8,offset=16).copy().reshape(count,1,28,28)
        else:
            assert magic==2049
            array=np.frombuffer(raw,dtype=np.uint8,offset=8).copy()
        arrays[name]=torch.from_numpy(array)
    return (arrays['train-images-idx3-ubyte.gz'],arrays['train-labels-idx1-ubyte.gz'].long(),
            arrays['t10k-images-idx3-ubyte.gz'],arrays['t10k-labels-idx1-ubyte.gz'].long())

class TimeEmbedding(nn.Module):
    def __init__(self,dim=128):
        super().__init__();self.dim=dim
        self.mlp=nn.Sequential(nn.Linear(dim,dim),nn.SiLU(),nn.Linear(dim,dim))
    def forward(self,t):
        frequencies=torch.exp(-math.log(10000)*torch.arange(self.dim//2,device=t.device)/(self.dim//2-1))
        phase=t.float()[:,None]*frequencies[None,:]
        return self.mlp(torch.cat((phase.sin(),phase.cos()),dim=1))

class ResidualBlock(nn.Module):
    def __init__(self,inputs,outputs,time_dim=128):
        super().__init__()
        self.norm1=nn.GroupNorm(8,inputs);self.conv1=nn.Conv2d(inputs,outputs,3,padding=1)
        self.time=nn.Linear(time_dim,outputs)
        self.norm2=nn.GroupNorm(8,outputs);self.conv2=nn.Conv2d(outputs,outputs,3,padding=1)
        self.skip=nn.Identity() if inputs==outputs else nn.Conv2d(inputs,outputs,1)
    def forward(self,x,t):
        h=self.conv1(F.silu(self.norm1(x)))+self.time(F.silu(t))[:,:,None,None]
        return self.skip(x)+self.conv2(F.silu(self.norm2(h)))

class SmallUNet(nn.Module):
    """28 -> 14 -> 7 -> 14 -> 28, time-conditioned residual/skip U-Net."""
    def __init__(self,base=32):
        super().__init__();self.base=base
        self.time=TimeEmbedding(128);self.input=nn.Conv2d(1,base,3,padding=1)
        self.enc1=ResidualBlock(base,base)
        self.down1=nn.Conv2d(base,base,3,stride=2,padding=1)
        self.enc2=ResidualBlock(base,base*2)
        self.down2=nn.Conv2d(base*2,base*2,3,stride=2,padding=1)
        self.mid1=ResidualBlock(base*2,base*2);self.mid2=ResidualBlock(base*2,base*2)
        self.up2=nn.Conv2d(base*2,base*2,3,padding=1)
        self.dec2=ResidualBlock(base*4,base*2)
        self.up1=nn.Conv2d(base*2,base,3,padding=1)
        self.dec1=ResidualBlock(base*2,base)
        self.norm=nn.GroupNorm(8,base);self.output=nn.Conv2d(base,1,3,padding=1)
    def forward(self,x,t):
        temb=self.time(t)
        skip1=self.enc1(self.input(x),temb)
        skip2=self.enc2(self.down1(skip1),temb)
        h=self.mid2(self.mid1(self.down2(skip2),temb),temb)
        h=self.dec2(torch.cat((self.up2(F.interpolate(h,size=skip2.shape[-2:],mode='nearest')),skip2),1),temb)
        h=self.dec1(torch.cat((self.up1(F.interpolate(h,size=skip1.shape[-2:],mode='nearest')),skip1),1),temb)
        return self.output(F.silu(self.norm(h)))

class Diffusion:
    def __init__(self,timesteps=1000,device='cpu'):
        self.timesteps=timesteps
        self.betas=torch.linspace(1e-4,.02,timesteps,dtype=torch.float64,device=device)
        self.alphas=1-self.betas
        self.alpha_bars=torch.cumprod(self.alphas,dim=0)
    def q_sample(self,x0,t,noise):
        """Closed-form one-draw sample from q(x_t | x_0), paper Eq. 4."""
        abar=self.alpha_bars[t].to(x0.dtype).view(-1,1,1,1)
        return abar.sqrt()*x0+(1-abar).sqrt()*noise
    def coefficients(self,t,s):
        """Exact forward posterior q(x_s | x_t,x_0), allowing skipped indices.

        s=-1 denotes clean x_0 under the zero-based implementation convention.
        For s=t-1 these are the original DDPM posterior, Eq. 7.
        """
        at=self.alpha_bars[t]
        a_s=self.alpha_bars[s] if s>=0 else at.new_tensor(1.)
        effective_beta=1-at/a_s
        variance=(1-a_s)/(1-at)*effective_beta
        c0=a_s.sqrt()*effective_beta/(1-at)
        ct=(at/a_s).sqrt()*(1-a_s)/(1-at)
        return c0.float(),ct.float(),variance.clamp_min(0).float()
    def indices(self,steps):
        if not 2<=steps<=self.timesteps:raise ValueError('Sampling steps must be between 2 and T.')
        selected=torch.linspace(0,self.timesteps-1,steps,dtype=torch.float64).round().long().tolist()
        assert len(set(selected))==steps and selected[0]==0 and selected[-1]==self.timesteps-1
        return selected[::-1]
    @torch.inference_mode()
    def sample(self,model,count,steps,seed,method='ddpm',amp=False):
        device=next(model.parameters()).device
        generator=torch.Generator(device=device).manual_seed(seed)
        x=torch.randn((count,1,28,28),generator=generator,device=device)
        indices=self.indices(steps)
        for index,t in enumerate(indices):
            s=indices[index+1] if index+1<len(indices) else -1
            times=torch.full((count,),t,device=device,dtype=torch.long)
            with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=amp and device.type=='cuda'):
                epsilon=model(x,times)
            at=self.alpha_bars[t].float()
            predicted_x0=((x-(1-at).sqrt()*epsilon.float())/at.sqrt()).clamp(-1,1)
            if method=='ddpm':
                c0,ct,var=self.coefficients(t,s)
                x=c0*predicted_x0+ct*x
                if s>=0:x=x+var.sqrt()*torch.randn(x.shape,generator=generator,device=device)
            elif method=='ddim':
                a_s=self.alpha_bars[s].float() if s>=0 else at.new_tensor(1.)
                # Recompute epsilon after clipping x0, keeping the decomposition consistent.
                eps=(x-at.sqrt()*predicted_x0)/(1-at).sqrt()
                x=a_s.sqrt()*predicted_x0+(1-a_s).sqrt()*eps
            else:raise ValueError(method)
        return x.clamp(-1,1)

def image_grid(images,path,columns=8):
    values=images.detach().cpu()
    if values.dtype!=torch.uint8:values=((values.clamp(-1,1)+1)*127.5).round().to(torch.uint8)
    count=len(values);rows=math.ceil(count/columns);gap=2
    grid=np.zeros((rows*28+(rows+1)*gap,columns*28+(columns+1)*gap),dtype=np.uint8)
    for i,value in enumerate(values):
        row,col=divmod(i,columns);y=gap+row*(28+gap);x=gap+col*(28+gap)
        grid[y:y+28,x:x+28]=value[0].numpy()
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True);Image.fromarray(grid).save(path)

def synchronize(device):
    if device.type=='cuda':torch.cuda.synchronize()

def environment(device):
    return {'python':platform.python_version(),'torch':torch.__version__,'numpy':np.__version__,
        'device':str(device),'hardware':torch.cuda.get_device_name(0) if device.type=='cuda' else platform.processor(),
        'cuda':torch.version.cuda,'threads':torch.get_num_threads(),'platform':platform.platform()}

@torch.inference_mode()
def validation_mse(model,images,diffusion,amp):
    model.eval();generator=torch.Generator(device=images.device).manual_seed(9001)
    total=0.
    for batch in images.split(256):
        t=torch.randint(diffusion.timesteps,(len(batch),),generator=generator,device=batch.device)
        noise=torch.randn(batch.shape,generator=generator,device=batch.device)
        noisy=diffusion.q_sample(batch,t,noise)
        with torch.autocast(device_type=batch.device.type,dtype=torch.float16,enabled=amp):prediction=model(noisy,t)
        total+=float(F.mse_loss(prediction.float(),noise))*len(batch)
    model.train();return total/len(images)

def train(args):
    device=torch.device(args.device);amp=device.type=='cuda'
    torch.manual_seed(args.seed);torch.set_num_threads(args.threads)
    if amp:torch.cuda.manual_seed_all(args.seed);torch.backends.cudnn.benchmark=True
    raw,_,_,_=load_mnist(ROOT/'data')
    split=torch.randperm(len(raw),generator=torch.Generator().manual_seed(31415))
    train_ids,val_ids=split[:55000],split[55000:]
    images=raw.to(device,dtype=torch.float32)/127.5-1
    train_images,val_images=images[train_ids.to(device)],images[val_ids.to(device)]
    model=SmallUNet(args.base).to(device);ema=copy.deepcopy(model).eval()
    for parameter in ema.parameters():parameter.requires_grad_(False)
    optimizer=torch.optim.AdamW(model.parameters(),lr=args.lr,weight_decay=1e-4)
    scaler=torch.amp.GradScaler('cuda',init_scale=1024,enabled=amp)
    diffusion=Diffusion(device=device)
    config={'epochs':args.epochs,'batch':args.batch,'seed':args.seed,'base':args.base,'lr':args.lr,
        'timesteps':1000,'beta_start':1e-4,'beta_end':.02,'ema_decay':.995,
        'train_images':55000,'validation_images':5000,'split_seed':31415,
        'normalization':'uint8 / 127.5 - 1','loss':'uniform-t epsilon-prediction MSE',
        'source_sha256':sha256(__file__),'protocol_sha256':sha256(ROOT/'PROTOCOL.md'),
        'data_checksums':RESOURCES,'parameters':sum(p.numel() for p in model.parameters()),
        'environment':environment(device),'linear_convolution_precision':'float16 autocast with scaler' if amp else 'float32'}
    assert config['parameters']<=5_000_000
    out=ROOT/'runs/main';out.mkdir(parents=True,exist_ok=True)
    checkpoint=out/'resume.pt';start=0;history=[];train_seconds=0.;updates=0
    generator=torch.Generator().manual_seed(args.seed+1)
    if checkpoint.exists():
        state=torch.load(checkpoint,map_location='cpu',weights_only=False)
        assert state['config']==config,'Existing run differs; use a fresh project directory.'
        model.load_state_dict(state['model']);ema.load_state_dict(state['ema'])
        optimizer.load_state_dict(state['optimizer']);scaler.load_state_dict(state['scaler'])
        start=state['epoch'];history=state['history'];train_seconds=state['train_seconds'];updates=state['updates']
        generator.set_state(state['data_rng']);torch.set_rng_state(state['cpu_rng'])
        if amp:torch.cuda.set_rng_state_all(state['cuda_rng'])
    write_json(out/'config.json',config)
    print('TRAIN_START',json.dumps({'parameters':config['parameters'],'environment':config['environment'],'start_epoch':start}),flush=True)
    active_start=time.perf_counter()
    for epoch in range(start,args.epochs):
        model.train();order=torch.randperm(len(train_images),generator=generator).to(device)
        total=0.;seen=0;synchronize(device);epoch_start=time.perf_counter()
        for ids in order.split(args.batch):
            x0=train_images[ids];t=torch.randint(1000,(len(ids),),device=device);noise=torch.randn_like(x0)
            xt=diffusion.q_sample(x0,t,noise)
            optimizer.zero_grad(set_to_none=True)
            with torch.autocast(device_type=device.type,dtype=torch.float16,enabled=amp):prediction=model(xt,t)
            loss=F.mse_loss(prediction.float(),noise)
            assert torch.isfinite(loss),'Non-finite loss'
            scaler.scale(loss).backward();scaler.unscale_(optimizer)
            norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1.)
            assert torch.isfinite(norm),'Non-finite gradient'
            old_scale=scaler.get_scale();scaler.step(optimizer);scaler.update()
            assert scaler.get_scale()>=old_scale,'An optimizer update was skipped; investigate precision.'
            with torch.no_grad():
                for target,source in zip(ema.parameters(),model.parameters()):target.lerp_(source,1-.995)
            total+=float(loss.detach())*len(ids);seen+=len(ids);updates+=1
        synchronize(device);seconds=time.perf_counter()-epoch_start;train_seconds+=seconds
        row={'epoch':epoch+1,'updates':updates,'training_mse':total/seen,
            'validation_mse_ema':validation_mse(ema,val_images,diffusion,amp),
            'epoch_training_seconds':seconds,'cumulative_training_seconds':train_seconds}
        history.append(row);print('EPOCH',json.dumps(row),flush=True)
        state={'config':config,'epoch':epoch+1,'model':model.state_dict(),'ema':ema.state_dict(),
            'optimizer':optimizer.state_dict(),'scaler':scaler.state_dict(),'history':history,
            'train_seconds':train_seconds,'updates':updates,'data_rng':generator.get_state(),
            'cpu_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all() if amp else None}
        atomic_save(state,checkpoint);write_json(out/'history.json',history)
        if (epoch+1)%3==0 or epoch+1==args.epochs:
            backup(checkpoint);backup(out/'config.json');backup(out/'history.json')
    weights={'model':{k:v.detach().cpu() for k,v in ema.state_dict().items()},'config':config,
             'epoch':args.epochs,'updates':updates,'weights':'EMA decay 0.995'}
    atomic_save(weights,out/'model_ema.pt');backup(out/'model_ema.pt')
    result={'config':config,'history':history,'updates':updates,'training_seconds':train_seconds,
        'active_fit_wall_seconds_this_invocation':time.perf_counter()-active_start,
        'weights_sha256':sha256(out/'model_ema.pt'),'training_completed':True}
    write_json(out/'training_result.json',result);backup(out/'training_result.json')
    print('TRAIN_COMPLETE',json.dumps({'updates':updates,'training_seconds':train_seconds,'weights_sha256':result['weights_sha256']}),flush=True)

class DigitClassifier(nn.Module):
    def __init__(self):
        super().__init__()
        self.conv=nn.Sequential(nn.Conv2d(1,16,3,padding=1),nn.ReLU(),nn.MaxPool2d(2),
            nn.Conv2d(16,32,3,padding=1),nn.ReLU(),nn.MaxPool2d(2))
        self.features=nn.Sequential(nn.Flatten(),nn.Linear(32*7*7,64),nn.ReLU())
        self.head=nn.Linear(64,10)
    def forward(self,x,features=False):
        h=self.features(self.conv(x));return h if features else self.head(h)

def train_classifier(device):
    torch.manual_seed(2718)
    raw,y,test_raw,test_y=load_mnist(ROOT/'data')
    x=raw.to(device,dtype=torch.float32)/127.5-1;y=y.to(device)
    test_x=test_raw.to(device,dtype=torch.float32)/127.5-1;test_y=test_y.to(device)
    model=DigitClassifier().to(device);optimizer=torch.optim.Adam(model.parameters(),lr=.001)
    rows=[]
    for epoch in range(3):
        model.train();order=torch.randperm(len(x),device=device);total=0.
        for ids in order.split(256):
            optimizer.zero_grad(set_to_none=True);loss=F.cross_entropy(model(x[ids]),y[ids]);loss.backward();optimizer.step()
            total+=float(loss.detach())*len(ids)
        rows.append({'epoch':epoch+1,'training_cross_entropy':total/len(x)})
    model.eval()
    with torch.inference_mode():
        correct=sum(int((model(b).argmax(1)==label).sum()) for b,label in zip(test_x.split(512),test_y.split(512)))
    result={'epochs':3,'seed':2718,'train_images':60000,'test_images':10000,'test_accuracy':correct/10000,
        'features':'64-dimensional penultimate ReLU; not an ImageNet Inception FID','history':rows}
    atomic_save({'model':model.cpu().state_dict(),'result':result},ROOT/'runs/classifier.pt');model.to(device)
    write_json(ROOT/'runs/classifier_result.json',result)
    print('CLASSIFIER_COMPLETE',json.dumps(result),flush=True)
    return model,test_x

@torch.inference_mode()
def feature_statistics(classifier,images):
    values=[];probabilities=[]
    for batch in images.split(256):
        feature=classifier(batch,features=True);values.append(feature.cpu().double())
        probabilities.append(classifier.head(feature).softmax(1).cpu())
    values=torch.cat(values);probabilities=torch.cat(probabilities)
    mean=values.mean(0);centered=values-mean
    covariance=centered.T@centered/(len(values)-1)
    return mean,covariance,probabilities

def feature_distance(stats1,stats2):
    m1,c1=stats1[:2];m2,c2=stats2[:2]
    eig,vectors=torch.linalg.eigh((c1+c1.T)/2)
    root=(vectors*eig.clamp_min(0).sqrt())@vectors.T
    product=root@c2@root
    cross=torch.linalg.eigvalsh((product+product.T)/2).clamp_min(0).sqrt().sum()
    return float(((m1-m2).square().sum()+torch.trace(c1)+torch.trace(c2)-2*cross).clamp_min(0))

def evaluate(args):
    device=torch.device(args.device);torch.set_num_threads(args.threads)
    if device.type=='cuda':torch.backends.cudnn.benchmark=True
    state=torch.load(ROOT/'runs/main/model_ema.pt',map_location='cpu',weights_only=False)
    assert state['config']['source_sha256']==sha256(__file__),'Source changed after training'
    model=SmallUNet(state['config']['base']).to(device);model.load_state_dict(state['model']);model.eval()
    diffusion=Diffusion(device=device);amp=device.type=='cuda'
    classifier,test_x=train_classifier(device)
    order=torch.randperm(len(test_x),generator=torch.Generator().manual_seed(1618)).to(device)
    reference=feature_statistics(classifier,test_x[order[:2048]])
    calibration=feature_statistics(classifier,test_x[order[2048:2560]])
    settings=[('ddpm',1000),('ddpm',200),('ddpm',50),('ddim',50)]
    out=ROOT/'results';out.mkdir(exist_ok=True)
    # Warm up convolution kernels, then rotate settings across three timing repeats.
    diffusion.sample(model,64,5,9000,amp=amp);timings={f'{method}_{steps}':[] for method,steps in settings}
    for repetition in range(3):
        rotated=settings[repetition:]+settings[:repetition]
        for method,steps in rotated:
            synchronize(device);start=time.perf_counter()
            diffusion.sample(model,64,steps,2026+repetition,method,amp)
            synchronize(device);elapsed=time.perf_counter()-start
            timings[f'{method}_{steps}'].append(elapsed)
            print('TIMING',json.dumps({'repetition':repetition,'method':method,'steps':steps,'images':64,'seconds':elapsed}),flush=True)
    rows=[]
    for method,steps in settings:
        synchronize(device);start=time.perf_counter()
        samples=diffusion.sample(model,512,steps,2026,method,amp)
        synchronize(device);sample_seconds=time.perf_counter()-start
        pixels=((samples+1)*127.5).round().clamp(0,255).to(torch.uint8).cpu()
        # Metrics use exactly the persisted 8-bit samples, making them reproducible.
        stats=feature_statistics(classifier,pixels.to(device,dtype=torch.float32)/127.5-1)
        counts=torch.bincount(stats[2].argmax(1),minlength=10)
        distribution=counts.double()/len(pixels)
        entropy=float(-(distribution[distribution>0]*distribution[distribution>0].log()).sum()/math.log(10))
        row={'method':method,'steps':steps,'samples':512,'seed':2026,
            'grid_images':64,'grid_selection':'first 64 generated images, no filtering',
            'seconds_512':sample_seconds,'timings_64_seconds':timings[f'{method}_{steps}'],
            'median_64_seconds':float(np.median(timings[f'{method}_{steps}'])),
            'classifier_feature_distance':feature_distance(stats,reference),
            'mean_classifier_confidence':float(stats[2].max(1).values.mean()),
            'confidence_at_least_0_9_fraction':float((stats[2].max(1).values>=.9).float().mean()),
            'predicted_class_counts':counts.tolist(),'normalized_predicted_class_entropy':entropy}
        image_grid(pixels[:64],out/f'grid_{method}_{steps}.png')
        np.savez_compressed(out/f'samples_{method}_{steps}.npz',images=pixels.numpy())
        rows.append(row);write_json(out/'comparison_partial.json',rows)
        print('COMPARISON',json.dumps(row),flush=True)
    raw,_,_,_=load_mnist(ROOT/'data')
    originals=raw[:8].to(device,dtype=torch.float32)/127.5-1
    noise=torch.randn(originals.shape,generator=torch.Generator(device=device).manual_seed(808),device=device)
    noisy=[]
    for t in (0,49,199,499,999):
        times=torch.full((8,),t,device=device,dtype=torch.long);noisy.append(diffusion.q_sample(originals,times,noise).cpu())
    image_grid(torch.cat([originals.cpu()]+noisy),out/'forward_noising.png',columns=8)
    result={'rows':rows,'environment':environment(device),'checkpoint_sha256':sha256(ROOT/'runs/main/model_ema.pt'),
        'sampling':'same trained EMA weights, full-range uniformly spaced original time indices, clipped predicted x0, fixed-small posterior variance',
        'timing_protocol':'three rotated-order repeats, batch 64, CUDA synchronized, includes RNG and denoising; excludes model loading, plotting, metrics and file I/O',
        'quality_protocol':'512 fixed-seed unfiltered samples per method; 2048 MNIST-test reference images; 8-bit images persisted; diagnostic classifier features, not standard FID',
        'real_reference_calibration_distance':feature_distance(calibration,reference),
        'classifier_result':json.loads((ROOT/'runs/classifier_result.json').read_text())}
    write_json(out/'comparison.json',result)
    with (out/'comparison.csv').open('w',newline='',encoding='utf-8') as handle:
        columns=['method','steps','median_64_seconds','seconds_512','classifier_feature_distance','mean_classifier_confidence','normalized_predicted_class_entropy']
        writer=csv.DictWriter(handle,fieldnames=columns);writer.writeheader()
        writer.writerows({k:r[k] for k in columns} for r in rows)
    records=[]
    for folder in (ROOT/'results',ROOT/'runs'):
        for path in sorted(folder.rglob('*')):
            if path.is_file() and path.name!='resume.pt':
                record=backup(path)
                if record:records.append(record)
    write_json(ROOT/'backup_verification.json',records);backup(ROOT/'backup_verification.json')
    print('EVALUATION_COMPLETE',out/'comparison.json',flush=True)

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('command',choices=['train','evaluate'])
    parser.add_argument('--device',default='cpu',choices=['cpu','cuda'])
    parser.add_argument('--epochs',type=int,default=12)
    parser.add_argument('--batch',type=int,default=256)
    parser.add_argument('--base',type=int,default=32)
    parser.add_argument('--lr',type=float,default=2e-4)
    parser.add_argument('--seed',type=int,default=42)
    parser.add_argument('--threads',type=int,default=min(4,os.cpu_count() or 1))
    args=parser.parse_args()
    if args.command=='train':train(args)
    else:evaluate(args)

if __name__=='__main__':main()
