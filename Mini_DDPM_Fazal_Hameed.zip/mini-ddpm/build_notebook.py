"""Build a clean, self-contained Colab notebook with exact experiment source."""
import ast
import json
from pathlib import Path
ROOT=Path(__file__).resolve().parent
cells=[]
def md(text):cells.append({'cell_type':'markdown','metadata':{},'source':text.splitlines(True)})
def code(text):
    ast.parse(text)
    cells.append({'cell_type':'code','metadata':{},'source':text.splitlines(True),'execution_count':None,'outputs':[]})
md('# mini-ddpm: MNIST from scratch\n\nAuthor: Fazal Hameed.\n\n'
   'This clean notebook carries runnable source and commands, with no invented execution outputs. '
   'The recorded experiment uses a free T4 for speed; the CLI defaults to CPU. '
   'Read `PROTOCOL.md` for the fixed training and evaluation plan. The model has 550,465 parameters.\n')
payload={name:(ROOT/name).read_bytes().decode('utf-8') for name in
    ('mini_ddpm.py','test_ddpm.py','sample.py','analyze.py','evaluate_saved.py','PROTOCOL.md','README.md','requirements.txt')}
code('import os,sys,subprocess,json\nfrom pathlib import Path\nimport torch\n'
     "WORK=Path('/content/mini_ddpm')\nWORK.mkdir(exist_ok=True)\n"
     "subprocess.check_call([sys.executable,'-m','pip','install','-q','numpy','Pillow','matplotlib'])\n"
     f'SOURCES={payload!r}\n'+
     "for name,text in SOURCES.items():(WORK/name).write_bytes(text.encode('utf-8'))\n"
     "DEVICE='cuda' if torch.cuda.is_available() else 'cpu'\n"
     "print('Device:',DEVICE, 'PyTorch:',torch.__version__)\n"
     "def run(command):\n    process=subprocess.Popen(command,cwd=WORK,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,bufsize=1)\n    for line in process.stdout:print(line,end='',flush=True)\n    assert process.wait()==0,'Command failed; inspect output.'\n")
code("run([sys.executable,'test_ddpm.py'])\n")
md('## Train and compare\n\nFixed 12 epochs, seed 42, 55,000 training images and 5,000 validation images. '
   'Sampling uses the final EMA checkpoint. The evaluator is trained separately from scratch. '
   'Free GPU availability varies; CPU execution can take substantially longer.\n')
code("run([sys.executable,'mini_ddpm.py','train','--device',DEVICE,'--threads','2'])\n"
     "run([sys.executable,'mini_ddpm.py','evaluate','--device',DEVICE,'--threads','2'])\n"
     "run([sys.executable,'analyze.py'])\n")
code("from IPython.display import display,Image\n"
     "display(Image(filename=str(WORK/'results/loss_curves.png')))\n"
     "for name in ['grid_ddpm_1000.png','grid_ddpm_200.png','grid_ddpm_50.png','grid_ddim_50.png']:\n    print(name)\n    display(Image(filename=str(WORK/'results'/name)))\n"
     "print((WORK/'results/comparison.csv').read_text())\n")
md('## Preserve results\n\nColab runtime files are temporary. Download the model and evidence before disconnecting. '
   'The recorded submission includes the checked three-page report; its Windows PDF typesetter is separate '
   'from training and is not needed to run the experiment.\n')
code("import zipfile\nfrom google.colab import files\n"
     "archive=Path('/content/mini_ddpm_results.zip')\n"
     "with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:\n"
     "    for path in sorted(WORK.rglob('*')):\n"
     "        if path.is_file() and not any(p in ('data','__pycache__') for p in path.relative_to(WORK).parts) and path.name!='resume.pt':z.write(path,path.relative_to(WORK))\n"
     "files.download(str(archive))\n")
notebook={'nbformat':4,'nbformat_minor':5,'metadata':{'accelerator':'GPU',
    'colab':{'name':'mini_ddpm_colab.ipynb'},'kernelspec':{'name':'python3','display_name':'Python 3'},
    'language_info':{'name':'python'}},'cells':cells}
(ROOT/'mini_ddpm_colab.ipynb').write_text(json.dumps(notebook,indent=1,ensure_ascii=False),encoding='utf-8')
print('Created self-contained notebook:',len(cells),'cells')
