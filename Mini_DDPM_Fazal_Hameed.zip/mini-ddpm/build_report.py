"""Typeset the measured experiment as a fixed three-page report."""
from html import escape
import json
from pathlib import Path
from reportlab.pdfgen import canvas
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph,Table,TableStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parent
summary=json.loads((ROOT/'results/summary.json').read_text())
training=json.loads((ROOT/'runs/main/training_result.json').read_text())
comparison=json.loads((ROOT/'results/comparison.json').read_text())
rows=summary['rows'];by_key={(r['method'],r['steps']):r for r in rows}
output=ROOT/'output/pdf/Mini_DDPM_Report_Fazal_Hameed.pdf'
output.parent.mkdir(parents=True,exist_ok=True)
fonts=Path('C:/Windows/Fonts')
pdfmetrics.registerFont(TTFont('ReportArial',str(fonts/'arial.ttf')))
pdfmetrics.registerFont(TTFont('ReportArialBold',str(fonts/'arialbd.ttf')))
pdfmetrics.registerFontFamily('ReportArial',normal='ReportArial',bold='ReportArialBold',italic='ReportArial',boldItalic='ReportArialBold')
WIDTH,HEIGHT=A4;LEFT=42;RIGHT=WIDTH-42;CONTENT=RIGHT-LEFT
INK=colors.HexColor('#183e51');MUTED=colors.HexColor('#526875')
body=ParagraphStyle('Body',fontName='ReportArial',fontSize=9.3,leading=12.8,textColor=colors.HexColor('#172b36'))
small=ParagraphStyle('Small',parent=body,fontSize=8,leading=10.5)
tablebody=ParagraphStyle('Table',parent=small,fontSize=8.1,leading=10.6)
tablehead=ParagraphStyle('TableHead',parent=tablebody,fontName='ReportArialBold',textColor=colors.white)
c=canvas.Canvas(str(output),pagesize=A4)
c.setTitle('mini-ddpm: MNIST diffusion from scratch')
c.setAuthor('Fazal Hameed');c.setSubject('DDPM implementation and sampling-step experiment on MNIST')

def start(page,label):
    c.setStrokeColor(colors.HexColor('#c4d4dc'));c.line(LEFT,803,RIGHT,803)
    c.setFont('ReportArial',8);c.setFillColor(MUTED)
    c.drawString(LEFT,814,'MINI-DDPM  |  '+label.upper())
    c.drawString(LEFT,25,'Fazal Hameed  |  18 October 2026')
    c.drawRightString(RIGHT,25,f'{page} / 3')

def heading(text,y,x=LEFT):
    y-=6
    c.setFillColor(INK);c.setFont('ReportArialBold',12.5);c.drawString(x,y,text)
    return y-17

def paragraph(text,y,width=CONTENT,x=LEFT,style=body,gap=8):
    p=Paragraph(text,style);_,height=p.wrap(width,HEIGHT)
    assert y-height>=43,(text[:70],y,height)
    p.drawOn(c,x,y-height)
    return y-height-gap

def table(values,widths,y):
    cells=[[Paragraph(str(v),tablehead if i==0 else tablebody) for v in row] for i,row in enumerate(values)]
    t=Table(cells,colWidths=widths,hAlign='LEFT')
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),INK),('VALIGN',(0,0),(-1,-1),'TOP'),
        ('LEFTPADDING',(0,0),(-1,-1),7),('RIGHTPADDING',(0,0),(-1,-1),7),
        ('TOPPADDING',(0,0),(-1,-1),7),('BOTTOMPADDING',(0,0),(-1,-1),7),
        ('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.HexColor('#edf3f6'),colors.white]),
        ('LINEBELOW',(0,-1),(-1,-1),.4,colors.HexColor('#c4d4dc'))]))
    _,height=t.wrap(CONTENT,HEIGHT);assert y-height>=43
    t.drawOn(c,LEFT,y-height);return y-height-12

def picture(name,x,top,width,height=None):
    from PIL import Image
    p=ROOT/'results'/name
    if height is None:
        with Image.open(p) as im:height=width*im.height/im.width
    c.drawImage(str(p),x,top-height,width=width,height=height)
    return top-height

start(1,'Method and training')
y=774
c.setFillColor(INK);c.setFont('ReportArialBold',20)
c.drawString(LEFT,y,'mini-ddpm: MNIST diffusion from scratch');y-=24
y=paragraph('Fazal Hameed | Experimental report | 18 October 2026',y,style=small,gap=13)
y=heading('Method',y)
y=paragraph('A miniature unconditional DDPM is trained from random initialization to predict Gaussian noise '
    'on 28 x 28 MNIST. The forward process, time-conditioned U-Net, loss and reverse sampler are implemented '
    'with basic PyTorch; no pretrained generator or diffusion framework is used. The linear schedule has '
    'T = 1,000, beta from 0.0001 to 0.02, and alpha_bar(T) = 0.00004036 [1].',y)
for equation in (
    'alpha_t = 1 - beta_t; alpha_bar_t = product(alpha_1 ... alpha_t)',
    'x_t = sqrt(alpha_bar_t) x_0 + sqrt(1 - alpha_bar_t) epsilon',
    'L = E[ || epsilon - epsilon_theta(x_t,t) ||^2 ], epsilon ~ N(0,I)'):
    c.setFont('Courier',8.6);c.setFillColor(INK);c.drawString(LEFT+6,y,equation);y-=14
y-=6
y=paragraph('The U-Net uses resolutions 28, 14 and 7, channel widths 32/64/64, six residual blocks, '
    'GroupNorm, SiLU, sinusoidal timestep embeddings, and encoder-decoder skip connections. '
    'Ancestral sampling starts at Gaussian noise, predicts and clips x_0 to [-1,1], and uses the fixed-small '
    'Gaussian posterior variance. The final clean transition adds no noise.',y)
y=heading('Training setup and recorded outcome',y)
values=[['Item','Recorded setting'],
    ['Data / scaling','55,000 train + 5,000 validation; fixed split seed 31415; pixels / 127.5 - 1'],
    ['Capacity / optimization',f"{summary['parameters']:,} parameters; AdamW, LR 0.0002, weight decay 0.0001; gradient clip 1.0"],
    ['Budget / weights',f"12 epochs; batch 256; {summary['updates']:,} updates; seed 42; final EMA, decay 0.995"],
    ['Hardware / software','Free Tesla T4; PyTorch 2.11.0+cu130; Python 3.13.15; two CPU threads'],
    ['Precision','FP32 parameters; FP16 convolution/linear autocast; gradient scaling, initial scale 1,024'],
    ['Measured training',f"{summary['training_seconds']:.2f} s ({summary['training_seconds']/60:.2f} min), synchronized epoch fit loops; excludes validation/checkpoint I/O"],
    ['Final loss',f"Online training MSE {summary['final_training_mse']:.5f}; EMA validation MSE {summary['final_validation_mse_ema']:.5f}"]]
y=table(values,[104,CONTENT-104],y)
top=y-2
picture('loss_curves.png',LEFT,top,300,160)
picture('forward_noising.png',LEFT+316,top,195)
caption_y=top-166
paragraph('Figure 1. Full epoch history; validation uses fixed noise/timesteps. Online training and EMA '
    'validation weights differ.',caption_y,width=300,style=small)
paragraph('Figure 2. Eight input digits (top), then noising at original steps 1, 50, 200, 500 and 1,000. '
    'Rows share the same epsilon.',caption_y,width=195,x=LEFT+316,style=small)
c.showPage()

start(2,'Sampling comparison')
y=774;y=heading('Required 8 x 8 ancestral sample grids',y)
y=paragraph('The first 64 of 512 generated images are shown for each setting, without quality filtering. '
    'All settings use the same final EMA checkpoint and sampling seed 2026. Initial noise is shared; '
    'intermediate random paths differ between chain lengths.',y,style=small,gap=14)
grid_width=(CONTENT-20)/3
grid_top=y-17
for i,steps in enumerate((1000,200,50)):
    x=LEFT+i*(grid_width+10)
    c.setFont('ReportArialBold',10);c.setFillColor(INK);c.drawString(x,y,f'DDPM: {steps:,} steps')
    picture(f'grid_ddpm_{steps}.png',x,grid_top,grid_width)
y=grid_top-grid_width-22
y=heading('Runtime and quantitative diagnostics',y)
values=[['Sampler','Steps','64 images, seconds<br/>median [min, max]','Speedup','MNIST feature<br/>distance (lower)','Confidence<br/>&gt;= 0.9 (%)']]
for row in rows:
    ts=row['timings_64_seconds']
    values.append([row['method'].upper()+(' (bonus)' if row['method']=='ddim' else ''),str(row['steps']),
        f"{row['median_64_seconds']:.3f} [{min(ts):.3f}, {max(ts):.3f}]",f"{row['speedup_vs_ddpm1000']:.2f}x",
        f"{row['classifier_feature_distance']:.2f}",f"{100*row['confidence_at_least_0_9_fraction']:.2f}"])
y=table(values,[60,42,124,59,110,CONTENT-395],y)
y=paragraph('Runtime: three rotated-order repeats with batch 64 after kernel warm-up; CUDA is synchronized '
    'around generation. Timing includes random draws and denoising, and excludes loading, plotting, metrics and '
    'file I/O. Quality uses a separate fixed 512-image batch per setting. The report makes no laptop CPU runtime claim.',y,style=small)
y=paragraph(f"Evaluator: a separate CNN trained from scratch for three epochs reaches {100*summary['classifier_test_accuracy']:.2f}% "
    'accuracy on the 10,000-image MNIST test set. Feature distance compares mean/covariance of its 64-dimensional '
    'penultimate features against 2,048 fixed test images. This is <b>not standard Inception FID</b>. '
    f"A disjoint real-512 versus reference calibration scores {summary['real_reference_calibration_distance']:.2f}. "
    'Confidence on unlabeled generated images is a diagnostic, not classification accuracy.',y,style=small)
y=heading('What the comparison shows',y)
y=paragraph('Many samples have recognizable digit shapes, but every grid also contains ambiguous or malformed '
    'digits. In this run, 1,000-step DDPM has the lowest measured feature distance. At 200 steps, generation is '
    f"{by_key['ddpm',200]['speedup_vs_ddpm1000']:.2f}x faster and the high-confidence fraction is "
    f"{100*by_key['ddpm',200]['confidence_at_least_0_9_fraction']:.2f}% versus "
    f"{100*by_key['ddpm',1000]['confidence_at_least_0_9_fraction']:.2f}%. "
    f"At 50 steps, speed rises to {by_key['ddpm',50]['speedup_vs_ddpm1000']:.2f}x, with worse feature distance and "
    'a lower high-confidence fraction. All settings receive predictions spanning all ten classes; predicted-class '
    'entropy is 0.979-0.992 of the maximum. These finite-sample diagnostics do not establish a universal ranking.',y)
c.showPage()

start(3,'Bonus, issues and reproducibility')
y=774;y=heading('Optional bonus: deterministic DDIM, 50 steps',y)
picture('grid_ddim_50.png',LEFT,y-3,192)
right_x=LEFT+208;right_width=CONTENT-208
paragraph('DDIM uses the same trained noise predictor and time indices, with eta = 0 and no injected '
    'reverse-process noise [2]. Epsilon is recomputed after clipping the predicted x_0 to keep the '
    'decomposition consistent. The 8 x 8 grid again contains the first 64 unfiltered samples.',y-4,
    width=right_width,x=right_x)
paragraph(f"Its median batch-64 time is {by_key['ddim',50]['median_64_seconds']:.3f} s. "
    f"Feature distance is {by_key['ddim',50]['classifier_feature_distance']:.2f} and the high-confidence fraction "
    f"is {100*by_key['ddim',50]['confidence_at_least_0_9_fraction']:.2f}%. "
    'The bonus works, but does not improve quality over 50-step ancestral DDPM in this measured run. '
    'No class conditioning is implemented.',y-103,width=right_width,x=right_x)
y-=215
y=heading('Implementation issues and solutions',y)
for title,text in [
    ('Short chains and noise range.','Simply retaining the same beta endpoints in a new 50-step chain leaves '
     'alpha_bar(T) near 0.60, inconsistent with a standard-Gaussian start. The 200/50-step samplers retain the '
     'original alpha-bar marginals and recompute the Gaussian posterior for each selected jump [3].'),
    ('Indices, clipping and numerical stability.','The code uses indices 0-999 and s = -1 for the clean image. '
     'Schedule products use FP64; image computation uses FP32. Predicted x_0 is clipped and posterior variances '
     'are clamped against rounding error. Tests check adjacent-posterior equivalence and the noiseless final step.'),
    ('Live execution logs.','The first evaluation was interrupted while diagnosing missing notebook subprocess '
     'output. Completed generator and classifier weights were preserved. Final comparisons were rerun with '
     'streamed logs and the same fixed checkpoints; partial interrupted timings are not used.')]:
    y=paragraph('<b>'+title+'</b> '+text,y,gap=7)
y=heading('Reproducibility and limits',y)
y=paragraph('The submission includes runnable PyTorch source, EMA generator and evaluator weights, exact setup, '
    'losses, all generated batches, timing repetitions, and seven passing equation/CPU tests. A CPU sampling '
    'smoke test also loads the supplied weights. MNIST gzip checksums and source hashes are retained. '
    'The code supports CPU training and sampling; full CPU training time was not measured. One generator seed, '
    '512 samples per setting and an imperfect digit classifier limit quality conclusions. More training, '
    'independent sample seeds and blinded human judgments could strengthen evaluation.',y)
y=paragraph('<b>Run:</b> <font name="Courier" size="8">python -m pip install -r requirements.txt</font><br/>'
    '<font name="Courier" size="8">python test_ddpm.py</font><br/>'
    '<font name="Courier" size="8">python sample.py --device cpu --steps 200</font><br/>'
    '<font name="Courier" size="8">python mini_ddpm.py train --device cpu</font>',y,style=small,gap=9)
y=heading('References',y)
for text in [
    '[1] Ho, Jain and Abbeel (2020), DDPM. <link href="https://arxiv.org/abs/2006.11239" color="#166181">arxiv.org/abs/2006.11239</link>',
    '[2] Song, Meng and Ermon (2020), DDIM. <link href="https://arxiv.org/abs/2010.02502" color="#166181">arxiv.org/abs/2010.02502</link>',
    '[3] Respacing reference: <link href="https://github.com/openai/improved-diffusion/blob/main/improved_diffusion/respace.py" color="#166181">OpenAI improved-diffusion, respace.py</link>. MNIST: LeCun, Cortes and Burges; mirror/checksums documented in <link href="https://github.com/pytorch/vision/blob/main/torchvision/datasets/mnist.py" color="#166181">Torchvision datasets/mnist.py</link>.']:
    y=paragraph(text,y,style=small,gap=4)
c.save()
print(output)
