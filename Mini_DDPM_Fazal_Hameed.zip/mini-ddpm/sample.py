"""Generate an 8x8 grid from the supplied trained EMA checkpoint, without MNIST."""
import argparse
from pathlib import Path
import time
import torch
from mini_ddpm import SmallUNet,Diffusion,image_grid,synchronize

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint',default='runs/main/model_ema.pt')
    parser.add_argument('--steps',type=int,default=200)
    parser.add_argument('--method',choices=['ddpm','ddim'],default='ddpm')
    parser.add_argument('--device',choices=['cpu','cuda'],default='cpu')
    parser.add_argument('--threads',type=int,default=4)
    parser.add_argument('--seed',type=int,default=2026)
    parser.add_argument('--count',type=int,default=64)
    parser.add_argument('--output',default='samples.png')
    args=parser.parse_args();torch.set_num_threads(args.threads)
    device=torch.device(args.device)
    checkpoint=torch.load(args.checkpoint,map_location='cpu',weights_only=False)
    model=SmallUNet(checkpoint['config']['base']).to(device)
    model.load_state_dict(checkpoint['model']);model.eval()
    diffusion=Diffusion(device=device)
    synchronize(device);start=time.perf_counter()
    images=diffusion.sample(model,args.count,args.steps,args.seed,args.method,device.type=='cuda')
    synchronize(device);seconds=time.perf_counter()-start
    image_grid(images,args.output)
    print(f'Saved {args.count} samples to {Path(args.output).resolve()} in {seconds:.3f} seconds on {device}.')

if __name__=='__main__':main()
